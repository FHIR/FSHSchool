# FSH School Basic Tutorial

The source code for the basic tutorial examples in FSH School.

For more information, see the [FSH School Basic Tutorial](https://fshschool.github.io/tutorials/basic).

When updates are to be published (incorporated into FSH School), download the zip from the master
branch, and put it into the content/tutorials/basic/ directory of the
[FSHSchool/site GitHub repository]().
